<?php


$dbServerName="localhost";
$dbName="unifonic";
$dbUserName="root";
$dbPassword="";

$dbConnection=mysqli_connect($dbServerName,$dbUserName,$dbPassword,$dbName);

if ($dbConnection->connect_error) {
    die("Connection failed: " . $dbConnection->connect_error);
} 