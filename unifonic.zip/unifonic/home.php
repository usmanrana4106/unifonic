<?php

include_once 'includes/dbconnection.php';

$firstName=$_POST['firstName'];
$lastName=$_POST['lastName'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$verificationCode=$_POST['verificationCode'];
$code=$_POST['code'];




if (empty($firstName) || empty($lastName) || empty($email) || empty($phone)) 
{
	header("Location: ./index.php?registration=empty"); /* Redirect browser */
	exit();
}

if (!preg_match("/^[A-Za-z]{1,20}$/", $firstName)) 
{
	header("Location: ./index.php?registration=FirstNameProblem"); /* Redirect browser */
	exit();
}
if (!preg_match("/^[A-Za-z]{1,20}$/", $lastName)) 
{
	header("Location: ./index.php?registration=LastNameProblem"); /* Redirect browser */
	exit();
}
if (filter_var($email, FILTER_VALIDATE_EMAIL))
{

}
else
{
	header("Location: ./index.php?registration=emailProblem"); /* Redirect browser */
	exit();
}
if (!preg_match("/^[9]{1}[0-9]{11}$/", $phone)) 
{
	header("Location: ./index.php?registration=mobileNumberProblem"); /* Redirect browser */
	exit();
}
if (!preg_match("/^[1-9]{4}$/", $verificationCode)) 
{
	header("Location: ./index.php?registration=verificationCodeProblem"); /* Redirect browser */
	exit();
}

if ($verificationCode != $code) 
{
	header("Location: ./index.php?registration=verificationCodeProblem2"); /* Redirect browser */
	exit();
}

$sql="INSERT INTO users ( firstName, lastName, email, phone,otp) VALUES ('$firstName','$lastName','$email',$phone,$verificationCode)";

if ($dbConnection->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $dbConnection->error;
}

header("Location: ./index.php?registration=success");





/* End of file home.php */