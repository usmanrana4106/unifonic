<!DOCTYPE html>
<html>
<head>
	<title>Registration Form</title>
	<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
</head>
<body>
<center>
  <form action="home.php" method="post">
	<legend>Registration form</legend>
	<div class="col-md-3">
		<label>first Name : </label>
	<input type="text" class="form-control" name="firstName" placeholder="first Name"> 
	</div>
	
	<div class="col-md-3">
		<label>Last Name : </label>
		<input type="text" class="form-control" name="lastName" placeholder="last Name">
	</div>
	
	<div class="col-md-3">
		<label>Email : </label>
		<input type="text" class="form-control" name="email" placeholder="Email">
	</div>

	<div class="col-md-3">
		<label>Phone : </label>
		<input type="number" class="form-control" name="phone"  id="phone" placeholder="Phone">
	</div>
	<div class="col-md-3">
		<label>Verification Code : </label>
		<input type="number" class="form-control" name="verificationCode" id="verificationCode" placeholder="Verification Code" maxlength="4">
	</div>
	<input type="hidden" name="code" id="code" placeholder="Verification Code" value="0">
	<br>
	<button type="submit"  class="btn btn-success"  name="submit">Submit</button>
	<br><br>

 </form>
	<button name="verification" class="btn btn-primary" onclick="Otp()"> Send Verfication SMS</button>
	</center>

<?php 
	
	$url="http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
	if (strpos($url, "registration=empty")) 
	{
		echo "<center><p>You Didnot fill all the Registration Fields </p></center>";
	}
	elseif (strpos($url, "registration=FirstNameProblem")) 
	{
		echo "<center><p>First Name is Required should be Alphabets and upto 20 Characters only. </p></center>";
	}
	elseif (strpos($url, "registration=LastNameProblem")) 
	{
		echo "<center><p>Last Name is Required should be Alphabets and upto 20 Characters only. </p></center>";
	}
	elseif (strpos($url, "registration=mobileNumberProblem")) 
	{
		echo "<center><p>Mobile Number is Required should be Numeric and upto 12 Characters only. </p></center>";
	}
	elseif (strpos($url, "registration=verificationCodeProblem")) 
	{
		echo "<center><p>Verification Code is Required should be Numeric and upto 4 Characters only. </p></center>";
	}
	elseif (strpos($url, "registration=verificationCodeProblem2")) 
	{
		echo "<center><p>Verification Code is not match with SMS. </p></center>";
	}
	elseif (strpos($url, "registration=success")) 
	{
		echo "<center><p>User is Registered Successfully!!! </p></center>";
	}


 ?>
<script type="text/javascript">
                     
                       $(document).ready(function () {
				        $('form').submit(function() {
				            return checkForTheCondition();
				        });
				    });
	                      function Otp()
	                      {
		                      	var val = Math.floor(1000 + Math.random() * 9000);
								
		                      	var phone=document.getElementById("phone").value
		                      	if (phone) 
		                      	{
		                      		$.ajax({
		                              url:"https://api.unifonic.com/rest/Messages/Send",
		                              type:"POST",
		                              data:{'AppSid' : "SpRpFe5w7P_5XNxBF8BSnuk6PxXTc0",'Recipient':phone,'Body':val,'SenderID':''},
		                              dataType:'json',
		                              success:function(data){
		                                alert(data.success);
										document.getElementById("code").value=val;

		                              },
		                              error:function(){
											document.getElementById("code").value=val;

		                                //alert('Error please check if it is not from cross platform.');
		                              }
		                            });
		                      	}
	                      		
	                      }
                        
                        function checkForTheCondition() 
                        {
							var code=document.getElementById("code").value;
							var verificationCode=document.getElementById("verificationCode").value;

                            if (verificationCode ==0 )
                            {
                            	alert("Verification Code is not Matched");
                            	return false;
                            }
                            else if (code==0) 
                            {
                            	alert("Please get the Verification Code by SMS");
                            	return false;
                            }
                            else if (verificationCode==code) 
                            {
                            	return true;
                            }

                            alert("Verification Code is not Matched");
                            	return false;
                        }


</script>

</body>
</html>